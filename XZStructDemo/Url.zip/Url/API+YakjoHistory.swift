//
//  API+YakjoHistory.swift
//  iClickKabu
//
//  Created by Cho on 2020/09/30.
//

import Foundation

extension API {
    // 約定履歴
    final class YakjoHistory: ApiTelegram {
        
        var path:           String { "stockExecutionHistoryList.do" }
        var method:         Method { .post }
        var errorHandler:   API.ErrorHandler? { .telegram }
        
        struct Parameter: Encodable {
            var dat: String        // 期間
            var dsf: Date          // 期間指定From
            var dst: Date          // 期間指定To
            var skc: String        // 証券コード
            var dot: String        // 表示順
            var adt: String        // 昇順／降順
            var pgn: String        // ページ番号
        }
    }
}
